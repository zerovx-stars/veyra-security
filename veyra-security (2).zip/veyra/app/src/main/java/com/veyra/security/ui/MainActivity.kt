package com.veyra.security.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.veyra.security.model.ThreatEvent
import com.veyra.security.model.ThreatLevel
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : ComponentActivity() {
    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VeyraTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                VeyraDashboard(
                    uiState       = uiState,
                    onEnableClick = { openNotificationListenerSettings() },
                    onClearClick  = { viewModel.clearHistory() },
                    onRefresh     = { viewModel.checkListenerStatus() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.checkListenerStatus()
    }

    private fun openNotificationListenerSettings() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }
}

// ── Theme ─────────────────────────────────────────────────────────────────────

private val VeyraBlack   = Color(0xFF0A0A0F)
private val VeyraSurface = Color(0xFF13131A)
private val VeyraCard    = Color(0xFF1C1C26)
private val VeyraAccent  = Color(0xFF6C63FF)
private val VeyraGreen   = Color(0xFF22C55E)
private val VeyraAmber   = Color(0xFFF59E0B)
private val VeyraRed     = Color(0xFFEF4444)
private val VeyraCrit    = Color(0xFFDC2626)
private val VeyraText    = Color(0xFFE8E8F0)
private val VeyraSubtext = Color(0xFF6B6B80)

@Composable
fun VeyraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background    = VeyraBlack,
            surface       = VeyraSurface,
            primary       = VeyraAccent,
            onBackground  = VeyraText,
            onSurface     = VeyraText
        ),
        content = content
    )
}

// ── Dashboard ─────────────────────────────────────────────────────────────────

@Composable
fun VeyraDashboard(
    uiState       : DashboardUiState,
    onEnableClick : () -> Unit,
    onClearClick  : () -> Unit,
    onRefresh     : () -> Unit
) {
    Scaffold(
        containerColor = VeyraBlack,
        topBar = { VeyraTopBar(onRefresh = onRefresh) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp, top = 8.dp)
        ) {
            // Protection status hero
            item {
                ProtectionStatusCard(
                    isActive      = uiState.isProtectionActive,
                    isEnabled     = uiState.isListenerEnabled,
                    onEnableClick = onEnableClick
                )
            }

            // Stats row
            item {
                StatsRow(stats = uiState.stats)
            }

            // Last threat banner
            uiState.lastThreatLabel?.let { label ->
                item {
                    LastThreatBanner(label = label)
                }
            }

            // History header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text  = "Riwayat Ancaman",
                        color = VeyraText,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                    if (uiState.recentEvents.isNotEmpty()) {
                        TextButton(onClick = onClearClick) {
                            Text("Hapus", color = VeyraSubtext, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Event list
            if (uiState.recentEvents.isEmpty()) {
                item {
                    EmptyHistoryCard()
                }
            } else {
                items(uiState.recentEvents, key = { it.id }) { event ->
                    ThreatEventCard(event = event)
                }
            }
        }
    }
}

// ── Components ────────────────────────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VeyraTopBar(onRefresh: () -> Unit) {
    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text       = "VEYRA",
                    fontWeight = FontWeight.Black,
                    fontSize   = 20.sp,
                    color      = VeyraAccent,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 4.sp
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text     = "SECURITY",
                    fontWeight = FontWeight.Light,
                    fontSize = 20.sp,
                    color    = VeyraText
                )
            }
        },
        actions = {
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = VeyraSubtext)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = VeyraBlack)
    )
}

@Composable
fun ProtectionStatusCard(
    isActive      : Boolean,
    isEnabled     : Boolean,
    onEnableClick : () -> Unit
) {
    val gradientColors = if (isActive)
        listOf(Color(0xFF1A1A3E), Color(0xFF0D1F0D))
    else
        listOf(Color(0xFF2A1A1A), Color(0xFF1A0D0D))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(16.dp),
        colors   = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .background(Brush.linearGradient(gradientColors))
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isActive) VeyraGreen else VeyraRed)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text  = if (isActive) "Perlindungan Aktif" else "Perlindungan Nonaktif",
                            color = VeyraText,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text  = if (isActive)
                            "WhatsApp sedang dipantau secara lokal"
                        else
                            "Izin notifikasi diperlukan untuk mulai",
                        color = VeyraSubtext,
                        fontSize = 12.sp
                    )
                }

                if (!isEnabled) {
                    Button(
                        onClick = onEnableClick,
                        colors  = ButtonDefaults.buttonColors(containerColor = VeyraAccent),
                        shape   = RoundedCornerShape(10.dp)
                    ) {
                        Text("Aktifkan", fontSize = 12.sp)
                    }
                } else {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        tint   = VeyraGreen,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatsRow(stats: com.veyra.security.model.ThreatStats) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        StatCard("Diblokir",     stats.totalBlocked.toString(),    VeyraAccent, Modifier.weight(1f))
        StatCard("Berbahaya",    stats.dangerousCount.toString(),   VeyraRed,   Modifier.weight(1f))
        StatCard("Mencurigakan", stats.suspiciousCount.toString(),  VeyraAmber, Modifier.weight(1f))
    }
}

@Composable
fun StatCard(label: String, value: String, accent: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = VeyraCard)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text       = value,
                color      = accent,
                fontWeight = FontWeight.Black,
                fontSize   = 24.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text     = label,
                color    = VeyraSubtext,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun LastThreatBanner(label: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(10.dp),
        colors   = CardDefaults.cardColors(containerColor = Color(0xFF2A1A1A))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Warning,
                contentDescription = null,
                tint     = VeyraRed,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text     = "Ancaman terakhir diblokir: $label",
                color    = VeyraRed,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ThreatEventCard(event: ThreatEvent) {
    val levelColor = when (event.threatLevel) {
        ThreatLevel.CRITICAL   -> VeyraCrit
        ThreatLevel.DANGEROUS  -> VeyraRed
        ThreatLevel.SUSPICIOUS -> VeyraAmber
        ThreatLevel.SAFE       -> VeyraGreen
    }
    val formatter = DateTimeFormatter.ofPattern("dd MMM, HH:mm:ss")
        .withZone(ZoneId.systemDefault())

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(10.dp),
        colors   = CardDefaults.cardColors(containerColor = VeyraCard)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(40.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(levelColor)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text       = event.patternLabel ?: event.patternId ?: "Unknown pattern",
                    color      = VeyraText,
                    fontWeight = FontWeight.Medium,
                    fontSize   = 13.sp
                )
                Text(
                    text     = event.packageName.removePrefix("com."),
                    color    = VeyraSubtext,
                    fontSize = 11.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text       = event.threatLevel.label,
                    color      = levelColor,
                    fontSize   = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text     = formatter.format(event.detectedAt),
                    color    = VeyraSubtext,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun EmptyHistoryCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(12.dp),
        colors   = CardDefaults.cardColors(containerColor = VeyraCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.CheckCircle,
                contentDescription = null,
                tint     = VeyraGreen,
                modifier = Modifier.size(40.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text       = "Tidak ada ancaman terdeteksi",
                color      = VeyraText,
                fontWeight = FontWeight.Medium,
                fontSize   = 14.sp
            )
            Text(
                text     = "Perangkat Anda aman",
                color    = VeyraSubtext,
                fontSize = 12.sp
            )
        }
    }
}
