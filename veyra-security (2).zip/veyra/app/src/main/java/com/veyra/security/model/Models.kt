package com.veyra.security.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.Instant

enum class ThreatLevel(val severity: Int, val label: String) {
    SAFE(0,       "Aman"),
    SUSPICIOUS(1, "Mencurigakan"),
    DANGEROUS(2,  "Berbahaya"),
    CRITICAL(3,   "Kritis")
}

@Entity(tableName = "threat_events")
data class ThreatEvent(
    @PrimaryKey(autoGenerate = true)
    val id           : Long        = 0,
    val packageName  : String,
    val threatLevel  : ThreatLevel,
    val patternId    : String?,
    val patternLabel : String?,
    val rawTitleHash : Int,
    val rawBodyHash  : Int,
    val detectedAt   : Instant     = Instant.now(),
    val wasBlocked   : Boolean     = true
)

data class ThreatStats(
    val totalBlocked   : Int = 0,
    val criticalCount  : Int = 0,
    val dangerousCount : Int = 0,
    val suspiciousCount: Int = 0,
    val lastDetected   : Instant? = null
)
