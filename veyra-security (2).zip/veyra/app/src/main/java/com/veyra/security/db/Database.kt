package com.veyra.security.db

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.veyra.security.model.ThreatEvent
import com.veyra.security.model.ThreatLevel
import com.veyra.security.model.ThreatStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant

// ── TypeConverters ────────────────────────────────────────────────────────────

class VeyraConverters {
    @TypeConverter fun fromInstant(v: Instant?): Long? = v?.toEpochMilli()
    @TypeConverter fun toInstant(v: Long?): Instant?   = v?.let { Instant.ofEpochMilli(it) }
    @TypeConverter fun fromLevel(v: ThreatLevel): Int  = v.severity
    @TypeConverter fun toLevel(v: Int): ThreatLevel    =
        ThreatLevel.entries.first { it.severity == v }
}

// ── DAO ───────────────────────────────────────────────────────────────────────

@Dao
interface ThreatEventDao {

    @Insert
    suspend fun insert(event: ThreatEvent): Long

    @Query("SELECT * FROM threat_events ORDER BY detectedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int = 100): Flow<List<ThreatEvent>>

    @Query("SELECT * FROM threat_events ORDER BY detectedAt DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 50): List<ThreatEvent>

    @Query("SELECT COUNT(*) FROM threat_events WHERE wasBlocked = 1")
    fun observeTotalBlocked(): Flow<Int>

    @Query("SELECT COUNT(*) FROM threat_events WHERE threatLevel = :level")
    suspend fun countByLevel(level: Int): Int

    @Query("SELECT MAX(detectedAt) FROM threat_events")
    suspend fun lastDetectedEpochMs(): Long?

    @Query("DELETE FROM threat_events WHERE detectedAt < :cutoffMs")
    suspend fun pruneOlderThan(cutoffMs: Long): Int

    @Query("DELETE FROM threat_events")
    suspend fun clearAll()
}

// ── Database ──────────────────────────────────────────────────────────────────

@Database(
    entities  = [ThreatEvent::class],
    version   = 1,
    exportSchema = true
)
@TypeConverters(VeyraConverters::class)
abstract class VeyraDatabase : RoomDatabase() {
    abstract fun threatEventDao(): ThreatEventDao

    companion object {
        @Volatile private var INSTANCE: VeyraDatabase? = null

        fun getInstance(context: Context): VeyraDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    VeyraDatabase::class.java,
                    "veyra_security.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
            }
    }
}

// ── Repository ────────────────────────────────────────────────────────────────

class ThreatLogRepository private constructor(private val dao: ThreatEventDao) {

    val recentEvents: Flow<List<ThreatEvent>> = dao.observeRecent()
    val totalBlocked: Flow<Int>               = dao.observeTotalBlocked()

    suspend fun record(event: ThreatEvent): Long = dao.insert(event)

    suspend fun getStats(): ThreatStats {
        val lastMs = dao.lastDetectedEpochMs()
        return ThreatStats(
            totalBlocked    = dao.countByLevel(-1).let { dao.getRecent(Int.MAX_VALUE).size },
            criticalCount   = dao.countByLevel(ThreatLevel.CRITICAL.severity),
            dangerousCount  = dao.countByLevel(ThreatLevel.DANGEROUS.severity),
            suspiciousCount = dao.countByLevel(ThreatLevel.SUSPICIOUS.severity),
            lastDetected    = lastMs?.let { Instant.ofEpochMilli(it) }
        )
    }

    /** Prune events older than 30 days to keep storage bounded. */
    suspend fun pruneOldEvents(): Int {
        val cutoff = Instant.now().minusSeconds(30L * 24 * 3600).toEpochMilli()
        return dao.pruneOlderThan(cutoff)
    }

    suspend fun clearAll() = dao.clearAll()

    companion object {
        @Volatile private var INSTANCE: ThreatLogRepository? = null

        fun getInstance(context: Context): ThreatLogRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: ThreatLogRepository(
                    VeyraDatabase.getInstance(context).threatEventDao()
                ).also { INSTANCE = it }
            }
    }
}
