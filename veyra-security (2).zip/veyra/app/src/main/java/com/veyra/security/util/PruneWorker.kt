package com.veyra.security.util

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.veyra.security.db.ThreatLogRepository

class PruneWorker(
    context: Context,
    params : WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val repo    = ThreatLogRepository.getInstance(applicationContext)
            val pruned  = repo.pruneOldEvents()
            Log.i("PruneWorker", "Pruned $pruned old threat events")
            Result.success()
        } catch (e: Exception) {
            Log.e("PruneWorker", "Prune failed", e)
            Result.retry()
        }
    }
}
