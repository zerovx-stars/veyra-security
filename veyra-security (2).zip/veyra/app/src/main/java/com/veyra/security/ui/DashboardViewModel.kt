package com.veyra.security.ui

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.veyra.security.core.VeyraNotificationService
import com.veyra.security.db.ThreatLogRepository
import com.veyra.security.model.ThreatEvent
import com.veyra.security.model.ThreatStats
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class DashboardUiState(
    val isListenerEnabled : Boolean         = false,
    val isProtectionActive: Boolean         = false,
    val recentEvents      : List<ThreatEvent> = emptyList(),
    val stats             : ThreatStats     = ThreatStats(),
    val lastThreatLabel   : String?         = null
)

class DashboardViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = ThreatLogRepository.getInstance(app)

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private val threatReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val label = intent.getStringExtra(VeyraNotificationService.EXTRA_PATTERN_LABEL)
            _uiState.update { it.copy(lastThreatLabel = label) }
            refreshStats()
        }
    }

    init {
        app.registerReceiver(
            threatReceiver,
            IntentFilter(VeyraNotificationService.ACTION_THREAT_DETECTED),
            Context.RECEIVER_NOT_EXPORTED
        )

        viewModelScope.launch {
            repo.recentEvents.collect { events ->
                _uiState.update { it.copy(recentEvents = events) }
            }
        }

        refreshStats()
        checkListenerStatus()
    }

    fun checkListenerStatus() {
        val app     = getApplication<Application>()
        val enabled = isNotificationListenerEnabled(app)
        val active  = enabled // service is active if permission granted
        _uiState.update { it.copy(isListenerEnabled = enabled, isProtectionActive = active) }
    }

    fun refreshStats() {
        viewModelScope.launch {
            val stats = repo.getStats()
            _uiState.update { it.copy(stats = stats) }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repo.clearAll()
            _uiState.update { it.copy(recentEvents = emptyList(), stats = ThreatStats()) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        getApplication<Application>().unregisterReceiver(threatReceiver)
    }

    private fun isNotificationListenerEnabled(context: Context): Boolean {
        val pkgName      = context.packageName
        val enabledFlat  = Settings.Secure.getString(
            context.contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabledFlat.split(":").any { it.startsWith(pkgName) }
    }
}
