package com.veyra.security.analysis

import com.veyra.security.model.ThreatLevel
import java.time.Instant

data class AnalysisResult(
    val level             : ThreatLevel,
    val matchedPatternId  : String?,
    val matchedLabel      : String?,
    val analysisTimeMs    : Long
)

data class PatternRule(
    val id       : String,
    val label    : String,
    val level    : ThreatLevel,
    val detector : (String) -> Boolean
)

/**
 * AnomalyEngine — local, stateless, zero-network pattern matcher.
 *
 * Each PatternRule encodes one observed attack vector. Rules are evaluated
 * in descending severity order; first match wins (short-circuit). Runtime
 * is O(n*k) where n = payload length and k = rule count — typically <2ms
 * on mid-range Android hardware for payloads under 16KB.
 *
 * Pattern catalogue covers:
 *   RTL_STACK     — directional override stacking (crashes bidi renderer)
 *   ZALGO_FLOOD   — combining-mark flood (hangs text layout engine)
 *   NULL_SURROGATE — null bytes / lone surrogates (parser crash)
 *   PAYLOAD_SIZE  — anomalous payload size (>8KB notification body)
 *   HOMOGLYPH     — script-mixing lookalike abuse (visual spoofing)
 *   REPEAT_FLOOD  — single-char flood (OOM via string allocation)
 *   ZERO_WIDTH    — zero-width joiner/non-joiner abuse (invisible payload)
 *   ESCAPE_INJECT — shell / HTML escape sequences in notification
 *   EMOJI_STORM   — dense emoji clusters (renderer hang)
 *   UNICODE_TAG   — Unicode tag-block usage (encoding abuse)
 */
class AnomalyEngine {

    private val rules: List<PatternRule> = buildRules()

    fun analyze(
        packageName : String,
        title       : String,
        body        : String,
        bigBody     : String,
        postedAt    : Instant = Instant.now()
    ): AnalysisResult {
        val t0 = System.currentTimeMillis()
        val payload = buildPayload(title, body, bigBody)

        // Evaluate CRITICAL → DANGEROUS → SUSPICIOUS → SAFE
        for (level in listOf(ThreatLevel.CRITICAL, ThreatLevel.DANGEROUS, ThreatLevel.SUSPICIOUS)) {
            for (rule in rules.filter { it.level == level }) {
                if (rule.detector(payload)) {
                    return AnalysisResult(
                        level            = rule.level,
                        matchedPatternId = rule.id,
                        matchedLabel     = rule.label,
                        analysisTimeMs   = System.currentTimeMillis() - t0
                    )
                }
            }
        }

        return AnalysisResult(
            level            = ThreatLevel.SAFE,
            matchedPatternId = null,
            matchedLabel     = null,
            analysisTimeMs   = System.currentTimeMillis() - t0
        )
    }

    private fun buildPayload(title: String, body: String, bigBody: String): String {
        // Deduplicate overlapping segments; bigBody usually contains body
        return if (bigBody.contains(body)) {
            "$title\n$bigBody"
        } else {
            "$title\n$body\n$bigBody"
        }
    }

    private fun buildRules(): List<PatternRule> = listOf(

        // ── CRITICAL ──────────────────────────────────────────────────────────

        PatternRule(
            id      = "NULL_SURROGATE_001",
            label   = "Null byte / surrogate injection",
            level   = ThreatLevel.CRITICAL,
            detector = { s ->
                s.any { it == '\u0000' } ||
                s.any { it.code in 0xD800..0xDFFF }
            }
        ),

        PatternRule(
            id      = "ESCAPE_INJECT_002",
            label   = "Escape sequence injection",
            level   = ThreatLevel.CRITICAL,
            detector = { s ->
                // Shell escape or HTML injection patterns in a notification body
                // are not legitimate — any occurrence is an exploit attempt
                s.contains("</script>", ignoreCase = true) ||
                s.contains("<iframe",   ignoreCase = true) ||
                s.contains("javascript:", ignoreCase = true) ||
                (s.count { it == '\u001B' } >= 2)  // ESC char sequences
            }
        ),

        PatternRule(
            id      = "UNICODE_TAG_003",
            label   = "Unicode tag-block abuse",
            level   = ThreatLevel.CRITICAL,
            detector = { s ->
                // U+E0000–U+E007F: tag characters, invisible, no legit use in notifications
                s.any { it.code in 0xE0000..0xE007F }
            }
        ),

        // ── DANGEROUS ─────────────────────────────────────────────────────────

        PatternRule(
            id      = "RTL_STACK_004",
            label   = "RTL override stacking",
            level   = ThreatLevel.DANGEROUS,
            detector = { s ->
                val rtlMarkers = s.count {
                    it == '\u202E' || // RIGHT-TO-LEFT OVERRIDE
                    it == '\u200F' || // RIGHT-TO-LEFT MARK
                    it == '\u061C' || // ARABIC LETTER MARK
                    it == '\u202B'    // RIGHT-TO-LEFT EMBEDDING
                }
                rtlMarkers >= 3
            }
        ),

        PatternRule(
            id      = "ZALGO_FLOOD_005",
            label   = "Combining-mark flood (Zalgo)",
            level   = ThreatLevel.DANGEROUS,
            detector = { s ->
                val combiningCount = s.count { it.category == CharCategory.NON_SPACING_MARK }
                combiningCount > 60
            }
        ),

        PatternRule(
            id      = "REPEAT_FLOOD_006",
            label   = "Single-character repetition flood",
            level   = ThreatLevel.DANGEROUS,
            detector = { s ->
                if (s.isEmpty()) false
                else {
                    // Find the longest run of any single character
                    var maxRun = 1; var curRun = 1
                    for (i in 1 until s.length) {
                        curRun = if (s[i] == s[i - 1]) curRun + 1 else 1
                        if (curRun > maxRun) maxRun = curRun
                    }
                    maxRun > 200
                }
            }
        ),

        PatternRule(
            id      = "EMOJI_STORM_007",
            label   = "Emoji cluster storm",
            level   = ThreatLevel.DANGEROUS,
            detector = { s ->
                // Emoji codepoints: U+1F000–U+1FFFF and Emoticons block
                val emojiCount = s.codePoints()
                    .filter { cp -> cp in 0x1F000..0x1FFFF || cp in 0x2600..0x27BF }
                    .count()
                emojiCount > 150
            }
        ),

        // ── SUSPICIOUS ────────────────────────────────────────────────────────

        PatternRule(
            id      = "PAYLOAD_SIZE_008",
            label   = "Anomalous payload size",
            level   = ThreatLevel.SUSPICIOUS,
            detector = { s -> s.length > 8_192 }
        ),

        PatternRule(
            id      = "HOMOGLYPH_009",
            label   = "Script-mixing / homoglyph abuse",
            level   = ThreatLevel.SUSPICIOUS,
            detector = { s ->
                val cyrillicCount = s.count { it in '\u0400'..'\u04FF' }
                val latinCount    = s.count { it in 'a'..'z' || it in 'A'..'Z' }
                cyrillicCount > 15 && latinCount < 10
            }
        ),

        PatternRule(
            id      = "ZERO_WIDTH_010",
            label   = "Zero-width character injection",
            level   = ThreatLevel.SUSPICIOUS,
            detector = { s ->
                val zwCount = s.count {
                    it == '\u200B' || // ZERO WIDTH SPACE
                    it == '\u200C' || // ZERO WIDTH NON-JOINER
                    it == '\u200D' || // ZERO WIDTH JOINER
                    it == '\uFEFF'    // BOM / ZERO WIDTH NO-BREAK SPACE
                }
                zwCount > 10
            }
        )
    )
}
