package com.veyra.security

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.*
import com.veyra.security.db.ThreatLogRepository
import com.veyra.security.util.PruneWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.util.concurrent.TimeUnit

class VeyraApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
        schedulePruneWorker()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_SERVICE,
                "Veyra Perlindungan",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status layanan pemantau Veyra Security"
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    /**
     * Schedule a daily background job to prune threat_events older than 30 days.
     * WorkManager survives process death and rescheduled across reboots.
     */
    private fun schedulePruneWorker() {
        val pruneRequest = PeriodicWorkRequestBuilder<PruneWorker>(1, TimeUnit.DAYS)
            .setConstraints(
                Constraints.Builder()
                    .setRequiresBatteryNotLow(true)
                    .build()
            )
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "veyra_prune",
            ExistingPeriodicWorkPolicy.KEEP,
            pruneRequest
        )
    }

    companion object {
        const val CHANNEL_SERVICE = "veyra_service_channel"
    }
}

// ── BootReceiver ──────────────────────────────────────────────────────────────

package com.veyra.security.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            // NotificationListenerService is re-bound by the system automatically
            // on boot if the permission is still granted — no explicit start needed.
            // This receiver exists to log the boot event and trigger WorkManager.
            Log.i("VeyraBootReceiver", "Boot completed — Veyra standing by")
        }
    }
}
