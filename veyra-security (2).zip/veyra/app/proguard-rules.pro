# Keep Room entities
-keep class com.veyra.security.model.** { *; }
-keep class com.veyra.security.db.**    { *; }

# Keep NotificationListenerService
-keep class com.veyra.security.core.VeyraNotificationService { *; }
-keep class com.veyra.security.core.BootReceiver             { *; }

# WorkManager worker
-keep class com.veyra.security.util.PruneWorker { *; }

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Room schema export
-keepclassmembers class * extends androidx.room.RoomDatabase {
    public static <fields>;
}
