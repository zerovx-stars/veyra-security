# Veyra Security

Pelindung keamanan Android lokal — mendeteksi dan memblokir notifikasi berbahaya WhatsApp sebelum dirender oleh sistem.

---

## Arsitektur

```
com.veyra.security/
├── VeyraApplication.kt          — Application class, WorkManager scheduler
├── core/
│   ├── VeyraNotificationService.kt  — NotificationListenerService (intercept + block)
│   └── BootReceiver.kt              — Restart guard setelah reboot
├── analysis/
│   └── AnomalyEngine.kt             — Pattern detection engine (10 rules)
├── db/
│   └── Database.kt                  — Room DB, DAO, Repository
├── model/
│   └── Models.kt                    — ThreatEvent entity, ThreatStats
├── ui/
│   ├── MainActivity.kt              — Compose dashboard
│   └── DashboardViewModel.kt        — UI state, BroadcastReceiver, stats
└── util/
    └── PruneWorker.kt               — Daily DB pruning (events > 30 hari)
```

---

## Pattern Catalogue

| ID                  | Level       | Deskripsi                                           |
|---------------------|-------------|-----------------------------------------------------|
| NULL_SURROGATE_001  | CRITICAL    | Null byte / lone surrogate injection                |
| ESCAPE_INJECT_002   | CRITICAL    | HTML/JS escape sequence injection                   |
| UNICODE_TAG_003     | CRITICAL    | Unicode tag-block abuse (U+E0000–U+E007F)           |
| RTL_STACK_004       | DANGEROUS   | RTL override stacking — crash bidi renderer         |
| ZALGO_FLOOD_005     | DANGEROUS   | Combining-mark flood > 60 chars                     |
| REPEAT_FLOOD_006    | DANGEROUS   | Single-char run > 200 — OOM string allocation       |
| EMOJI_STORM_007     | DANGEROUS   | Emoji density > 150 dalam satu notifikasi           |
| PAYLOAD_SIZE_008    | SUSPICIOUS  | Payload > 8KB — anomalous untuk notifikasi          |
| HOMOGLYPH_009       | SUSPICIOUS  | Script mixing Cyrillic + Latin lookalike            |
| ZERO_WIDTH_010      | SUSPICIOUS  | Zero-width character injection > 10 chars           |

---

## Jaminan Privasi

- **Tidak ada `INTERNET` permission** — tidak ada data yang keluar dari perangkat
- **Tidak ada `READ_CONTACTS`** — kontak tidak diakses
- **Tidak ada backup cloud** — database tidak pernah di-sinkronisasi
- **Raw content tidak tersimpan** — hanya `hashCode()` dari title dan body yang dicatat
- **Local-first** — semua pemrosesan terjadi di perangkat

---

## Cara Build

```bash
# Pastikan Android SDK terinstal dan ANDROID_HOME diset
./gradlew assembleDebug

# APK output:
# app/build/outputs/apk/debug/app-debug.apk
```

**Requirements:**
- Android Studio Hedgehog (2023.1.1) atau lebih baru
- Android SDK 34
- Kotlin 1.9.22
- JDK 17

---

## Flow Kerja

```
Notifikasi masuk (WhatsApp)
        ↓
VeyraNotificationService.onNotificationPosted()
        ↓
AnomalyEngine.analyze(title, body, bigBody)
        ↓
[ SAFE ] → biarkan lewat
[ SUSPICIOUS / DANGEROUS / CRITICAL ]
        ↓
cancelNotification(sbn.key)     ← blokir sebelum dirender
ThreatLogRepository.record()    ← catat (hashed only)
sendBroadcast(THREAT_DETECTED)  ← update UI real-time
```

---

## Izin yang Diminta

| Izin | Alasan |
|------|--------|
| `BIND_NOTIFICATION_LISTENER_SERVICE` | Membaca notifikasi WhatsApp untuk dianalisis |
| `RECEIVE_BOOT_COMPLETED` | Agar layanan aktif kembali setelah restart |
| `FOREGROUND_SERVICE` | Layanan persisten di latar belakang |
| `POST_NOTIFICATIONS` | Notifikasi status layanan (API 33+) |

---

## Lisensi

Open-source — MIT License. Kode ini bebas dipelajari, difork, dan dikembangkan.
